var express = require('express');
var router = express.Router();
var cassandra = require('cassandra-driver');

var client = new cassandra.Client({contactPoints: ['127.0.0.1'],  localDataCenter: 'datacenter1', keyspace: 'inf566'});
client.connect(function(err, result){
  console.log('addetudiant: cassandra connected');
});


/* ADD Etudiant. */
router.get('/', function(req, res) {    
        res.render('ajoutetudiant');     
    });  
  

  /*POST Add Etudiant*/
  router.post('/', function(req, res){
    id = cassandra.types.uuid();
    var upserStudent = 'INSERT INTO inf566.Etudiants (id, matricule, nom, prenom, sexe, email) VALUES (?, ?, ?, ?, ?, ?)';
    client.execute(upserStudent,[id, req.body.matricule, req.body.nom, req.body.prenom, req.body.sexe, req.body.email], 
    function(err, result){      
        if(err){
            console.log(uuid());
          res.status(404).send({msg: err});
        } else {
            console.log('Etudiant ajouté avec success')
          res.redirect('/');
        }
      });  
    });
      
  module.exports = router;