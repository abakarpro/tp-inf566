var express = require('express');
var router = express.Router();
var cassandra = require('cassandra-driver');

var client = new cassandra.Client({contactPoints: ['127.0.0.1'],  localDataCenter: 'datacenter1', keyspace: 'inf566'});
client.connect(function(err, result){
  console.log('etudiant: cassandra connected');
});

var getEtudiantById = 'SELECT * FROM inf566.Etudiants WHERE id = ?';

/* GET Etudiant by id. */
router.get('/:id', function(req, res, next) {
  client.execute(getEtudiantById,[req.params.id], function(err, result){
    if(err){
      res.status(404).send({msg: err});
    } else {
      res.render('etudiant', {
        id: result.rows[0].id,
        matricule: result.rows[0].matricule,
        nom: result.rows[0].nom,
        prenom: result.rows[0].prenom,
        sexe: result.rows[0].sexe,
        email: result.rows[0].email      })
    }
  });  
});

var deletudiant = "DELETE FROM inf566.Etudiants WHERE id = ?";

router.delete('/:id', function(req, res){
  client.execute(deletudiant, [req.params.id], function(err, result){
    if(err){
      res.status(404).send({msg: err});
    } else {
      res.json(result);
    }
  })
})

module.exports = router;
