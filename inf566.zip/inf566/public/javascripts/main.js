$(document).ready(function(){
    $('.deletudiant').on('click', delEtudiant);
});

function delEtudiant() {
    event.preventDefault();

    var confimation = confirm('Voulez-vous vraiment supprimer cet element ?');

    if(confimation){
        $.ajax({
            type: 'DELETE',
            url: '/etudiant/' + $('.deletudiant').data('id')
        }).done(function(response){
            window.location.replace('/');
        });
    } else {
        return false;
    }
}